package com.springmvc.helloworld;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class HelloWorldController{
	@RequestMapping(value="/welcome")
	public ModelAndView helloworld(){
		ModelAndView modelandview=new ModelAndView("index");
		
		return modelandview;
	}
	@RequestMapping(value="/helloworld")
	public ModelAndView print() {
		ModelAndView model=new ModelAndView("HelloWorld");
		model.addObject("msg", "Hello World!");
		return model;
	}
	
	
	@ResponseBody
	@RequestMapping(value="/hello")
	public String print1() {
		String s="Hello World";
		return s;
	}
	 

}
