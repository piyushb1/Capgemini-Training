package com.springmvc.simpleinterestcontroller;

public class SimpleInterest {
private int principalAmount;
private int year;
private int rate;

public int getPrincipalAmount() {
	return principalAmount;
}
public void setPrincipalAmount(int principalAmount) {
	this.principalAmount = principalAmount;
}
public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
}
public int getRate() {
	return rate;
}
public void setRate(int rate) {
	this.rate = rate;
}


}
