package com.springmvc.simpleinterestcontroller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SimpleInterestController {
	@RequestMapping(value="/insert.html", method = RequestMethod.GET)
	public ModelAndView getvalue() {
		ModelAndView model=new ModelAndView("calculateInterest");
		model.addObject("msg","Use Only To Calculate Simple Interest");
		return model;
	}

	@RequestMapping("/calculate.html")
	public ModelAndView calculate(@ModelAttribute("s1")SimpleInterest s1) {
	
		ModelAndView model=new ModelAndView("simpleInterest");
		model.addObject("msg", "Calculated the Simple Interest");
		
		return model;
		
		
	}
}
