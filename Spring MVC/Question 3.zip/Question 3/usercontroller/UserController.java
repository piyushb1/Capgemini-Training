package com.springmvc.usercontroller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {
	@RequestMapping(value="/HelloPage", method= RequestMethod.GET)
	public ModelAndView getlogin() {
		ModelAndView model=new ModelAndView("login");
		return model;
	}	
	@RequestMapping(value="/success.html", method= RequestMethod.POST)
	public ModelAndView submitlogin(@Valid @ModelAttribute("u1") User u1,BindingResult result){
		if(result.hasErrors()) {
        	ModelAndView model=new ModelAndView("login");
        	return model;
        }
		
		ModelAndView model=new ModelAndView("success");
		model.addObject("msg","WELCOME USER :)");
		return model;
		
		
	}
	
	
}
